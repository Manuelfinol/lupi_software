// src/components/LupiTeoria.js
import Lupi from "./Lupi";

export default function LupiTeoria({ texto }) {
  return (
    <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl shadow-md border border-blue-200 my-4">
      {/* Lupi */}
      <div className="flex-shrink-0">
        <Lupi emocion="hablando" mensaje={texto} />
      </div>

      {/* Burbuja */}
      <div className="bg-white p-4 rounded-xl shadow border border-gray-200">
        <p className="text-gray-800 text-lg leading-relaxed">{texto}</p>
      </div>
    </div>
  );
}
